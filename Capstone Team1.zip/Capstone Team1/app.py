# app.py
import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.figure_factory as ff

st.set_page_config(page_title="Urban Traffic Congestion Intelligence System",layout="wide")

@st.cache_data
def load_data():
    df=pd.read_csv("Banglore_traffic_Dataset - Banglore_traffic_Dataset.csv")
    #df["Date"]=pd.to_datetime(df["Date"])
    df["Date"] = pd.to_datetime(df["Date"], format="%d-%m-%Y")
    df["Year"]=df["Date"].dt.year
    df["Month"]=df["Date"].dt.month_name()
    df["Weekend"]=df["Date"].dt.dayofweek>=5
    return df
df=load_data()

st.sidebar.header("Filters")
areas=st.sidebar.multiselect("Area",sorted(df["Area Name"].unique()),default=sorted(df["Area Name"].unique()))
weather=st.sidebar.multiselect("Weather",sorted(df["Weather Conditions"].unique()),default=sorted(df["Weather Conditions"].unique()))
const=st.sidebar.multiselect("Construction",sorted(df["Roadwork and Construction Activity"].unique()),default=sorted(df["Roadwork and Construction Activity"].unique()))
f=df[df["Area Name"].isin(areas)&df["Weather Conditions"].isin(weather)&df["Roadwork and Construction Activity"].isin(const)]

st.title("🚦 Urban Traffic Congestion Intelligence System")
c1,c2,c3,c4=st.columns(4)
c1.metric("Records",len(f))
c2.metric("Avg Traffic",f["Traffic Volume"].mean().round(0))
c3.metric("Avg Speed",round(f["Average Speed"].mean(),1))
c4.metric("Avg Congestion",round(f["Congestion Level"].mean(),1))

tab1,tab2,tab3,tab4,tab5=st.tabs(["Overview","Area","Road","Factors","Insights"])

with tab1:
    a=f.groupby("Area Name",as_index=False)["Traffic Volume"].mean()
    st.plotly_chart(px.bar(a,x="Area Name",y="Traffic Volume",title="Average Traffic by Area"),use_container_width=True)
    s=f.select_dtypes("number").corr()
    st.plotly_chart(ff.create_annotated_heatmap(z=s.values,x=list(s.columns),y=list(s.columns),colorscale="RdBu"),use_container_width=True)

with tab2:
    col1,col2=st.columns(2)
    t=f.groupby("Area Name",as_index=False)["Traffic Volume"].mean()
    g=f.groupby("Area Name",as_index=False)["Congestion Level"].mean()
    col1.plotly_chart(px.bar(t,x="Area Name",y="Traffic Volume",color="Traffic Volume"),use_container_width=True)
    col2.plotly_chart(px.bar(g,x="Area Name",y="Congestion Level",color="Congestion Level"),use_container_width=True)

with tab3:
    col1,col2=st.columns(2)
    r=f.groupby("Road/Intersection Name",as_index=False)["Traffic Volume"].mean().sort_values("Traffic Volume",ascending=False).head(10)
    rc=f.groupby("Road/Intersection Name",as_index=False)["Congestion Level"].mean().sort_values("Congestion Level",ascending=False).head(10)
    col1.plotly_chart(px.bar(r,x="Traffic Volume",y="Road/Intersection Name",orientation="h"),use_container_width=True)
    col2.plotly_chart(px.bar(rc,x="Congestion Level",y="Road/Intersection Name",orientation="h"),use_container_width=True)

with tab4:
    c1,c2=st.columns(2)
    c1.plotly_chart(px.box(f,x="Weather Conditions",y="Traffic Volume",color="Weather Conditions"),use_container_width=True)
    c2.plotly_chart(px.scatter(f,x="Traffic Volume",y="Average Speed",color="Congestion Level",hover_data=["Area Name"]),use_container_width=True)

with tab5:
    ha=f.groupby("Area Name")["Congestion Level"].mean().idxmax()
    hr=f.groupby("Road/Intersection Name")["Congestion Level"].mean().idxmax()
    st.success(f"""Highest Congestion Area: {ha}

Highest Congestion Road: {hr}

Recommendations:
- Optimize signal timings.
- Prioritize Koramangala/high congestion corridors.
- Improve public transport.
- Monitor construction zones.
- Deploy dynamic traffic management.""")
    st.download_button("Download Filtered CSV",f.to_csv(index=False),"filtered_data.csv","text/csv")
