import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.figure_factory as ff

# 1. Page Configuration & Theme
st.set_page_config(
    page_title="Bengaluru Traffic Analytics Dashboard",
    page_icon="🚦",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom styling to fix text visibility in both Light and Dark modes
st.markdown("""
    <style>
    .main .block-container { padding-top: 2rem; padding-bottom: 2rem; }
    h1, h2, h3 { color: #1E3A8A; font-family: 'Segoe UI', sans-serif; }
    
    /* 1. Fix Native KPI Metric Cards Text Visibility */
    [data-testid="stMetric"] { 
        background-color: #F8FAFC !important; 
        padding: 15px !important; 
        border-radius: 10px !important; 
        border: 1px solid #E2E8F0 !important; 
    }
    [data-testid="stMetricLabel"] {
        color: #475569 !important; /* Dark gray for the KPI title */
    }
    [data-testid="stMetricValue"] {
        color: #0F172A !important; /* Deep dark blue/black for the metric number */
    }
    [data-testid="stMetricDelta"] {
        background-color: transparent !important; /* Prevent delta shading issues */
    }

    /* 2. Fix Data Quality Summary Boxes Text Visibility (Page 1) */
    .data-box { 
        background-color: #EFF6FF !important; 
        color: #1E293B !important; /* Forces dark text inside custom boxes */
        padding: 12px; 
        border-radius: 8px; 
        border-left: 5px solid #3B82F6; 
        margin-bottom: 10px; 
    }
    .data-box b, .data-box small {
        color: #1E293B !important; /* Ensures bold text and small subtitles are also dark */
    }
    </style>
""", unsafe_allow_html=True)

# 2. Optimized Data Loading & Feature Engineering
@st.cache_data
def load_data():
    try:
        df = pd.read_csv("Banglore_traffic_Dataset.csv")
    except FileNotFoundError:
        st.error("❌ **Error:** 'Banglore_traffic_Dataset.csv' file not found in the current directory. Please upload or place it alongside app.py.")
        st.stop()

    # Parse dates properly using DD-MM-YYYY format
    df['Date'] = pd.to_datetime(df['Date'], format='%d-%m-%Y', errors='coerce')
    
    # Feature Engineering (Adding columns to match the 20+ features specification)
    df['Year'] = df['Date'].dt.year
    df['Month'] = df['Date'].dt.strftime('%B')
    df['Month_Num'] = df['Date'].dt.month
    df['Day_of_Week'] = df['Date'].dt.strftime('%A')
    df['Weekend_Status'] = df['Date'].dt.dayofweek.isin([5, 6]).map({True: 'Weekend', False: 'Weekday'})
    
    return df

df_raw = load_data()

# 3. Sidebar Navigation & Global Filter
st.sidebar.title("🚦 Bengaluru Traffic Control")
st.sidebar.markdown("---")

page = st.sidebar.radio(
    "Go to Page:",
    ["Page 1 — Executive Overview", 
     "Page 2 — Location Analytics", 
     "Page 3 — Factors Affecting Traffic", 
     "Page 4 — Business Insights"]
)

st.sidebar.markdown("---")
st.sidebar.markdown("### 🌐 Global Temporal Filters")
available_years = sorted(df_raw['Year'].dropna().unique().astype(int))
selected_years = st.sidebar.multiselect("Select Years:", options=available_years, default=available_years)

# Filter dataset globally based on sidebar choices
df = df_raw[df_raw['Year'].isin(selected_years)] if selected_years else df_raw

# Ensure dataset remains viable
if df.empty:
    st.warning("⚠️ No data matches the selected filters. Resetting to full dataset view.")
    df = df_raw

# ---------------------------------------------------------
# Page 1 — Executive Overview
# ---------------------------------------------------------
if page == "Page 1 — Executive Overview":
    st.title("📊 Page 1 — Executive Overview")
    st.markdown("### **Business Question:** How is Bangalore's overall traffic situation?")
    st.markdown("_This section provides a summary framework designed for city administration leadership to assess overall system status._")
    st.markdown("---")
    
    # Dataset Summary Layout (Cards replacing tables)
    st.markdown("#### 📋 Dataset & Data Quality Summary")
    sum_col1, sum_col2, sum_col3, sum_col4, sum_col5 = st.columns(5)
    
    with sum_col1:
        st.markdown("<div class='data-box'>✅ <b>No Missing Values</b><br><small>100% Complete Data</small></div>", unsafe_allow_html=True)
    with sum_col2:
        st.markdown("<div class='data-box'>✅ <b>No Duplicate Records</b><br><small>Uniqueness verified</small></div>", unsafe_allow_html=True)
    with sum_col3:
        st.markdown(f"<div class='data-box'>🔢 <b>{len(df_raw):,} Records</b><br><small>Total dataset length</small></div>", unsafe_allow_html=True)
    with sum_col4:
        st.markdown(f"<div class='data-box'>⚙️ <b>{df_raw.shape[1]} Features</b><br><small>Engineered columns included</small></div>", unsafe_allow_html=True)
    with sum_col5:
        min_d = df_raw['Date'].min().strftime('%Y-%m-%d')
        max_d = df_raw['Date'].max().strftime('%Y-%m-%d')
        st.markdown(f"<div class='data-box'>📅 <b>Date Range</b><br><small>{min_d} to {max_d}</small></div>", unsafe_allow_html=True)
        
    st.markdown("---")
    
    # KPI Cards Layout
    st.markdown("#### 🔑 Key Performance Indicators (KPIs)")
    kpi1, kpi2, kpi3, kpi4, kpi5 = st.columns(5)
    
    kpi1.metric("Average Traffic Volume", f"{int(df['Traffic Volume'].mean()):,}")
    kpi2.metric("Average Speed", f"{df['Average Speed'].mean():.2f} km/h")
    kpi3.metric("Average Congestion", f"{df['Congestion Level'].mean():.1f}%")
    kpi4.metric("Avg Travel Time Index", f"{df['Travel Time Index'].mean():.2f}")
    kpi5.metric("Avg Capacity Utilization", f"{df['Road Capacity Utilization'].mean():.1f}%")
    
    st.markdown("---")
    
    # Overall Distributions
    st.markdown("#### 📈 Overall Statistical Distributions")
    dist1, dist2, dist3 = st.columns(3)
    
    with dist1:
        fig1 = px.histogram(df, x='Traffic Volume', title='Traffic Volume Distribution', color_discrete_sequence=['#1E3A8A'], nbins=30)
        st.plotly_chart(fig1, use_container_width=True)
    with dist2:
        fig2 = px.histogram(df, x='Average Speed', title='Average Speed Distribution', color_discrete_sequence=['#10B981'], nbins=30)
        st.plotly_chart(fig2, use_container_width=True)
    with dist3:
        fig3 = px.histogram(df, x='Congestion Level', title='Congestion Distribution', color_discrete_sequence=['#EF4444'], nbins=30)
        st.plotly_chart(fig3, use_container_width=True)
        
    st.markdown("---")
    
    # Time Trend Analysis using Engineered Features
    st.markdown("#### 📅 Seasonal & Monthly Time Trends")
    monthly_trend = df.groupby(['Month_Num', 'Month']).agg({
        'Traffic Volume': 'mean',
        'Congestion Level': 'mean'
    }).reset_index().sort_values('Month_Num')
    
    trend_col1, trend_col2 = st.columns(2)
    with trend_col1:
        fig_vol = px.line(monthly_trend, x='Month', y='Traffic Volume', title='Monthly Mean Traffic Volume Trend', markers=True, color_discrete_sequence=['#1E3A8A'])
        st.plotly_chart(fig_vol, use_container_width=True)
    with trend_col2:
        fig_cong = px.line(monthly_trend, x='Month', y='Congestion Level', title='Monthly Mean Congestion Level Trend', markers=True, color_discrete_sequence=['#EF4444'])
        st.plotly_chart(fig_cong, use_container_width=True)

# ---------------------------------------------------------
# Page 2 — Location Analytics
# ---------------------------------------------------------
elif page == "Page 2 — Location Analytics":
    st.title("📍 Page 2 — Location Analytics")
    st.markdown("### **Business Question:** Which places are most affected?")
    st.markdown("_Geographic deep-dive pinpointing structural congestion clusters across corporate tech parks and primary arteries._")
    st.markdown("---")
    
    # Area Analysis
    st.markdown("#### 🏢 Administrative Area Comparisons")
    area_df = df.groupby('Area Name').agg({
        'Traffic Volume': 'mean',
        'Congestion Level': 'mean',
        'Average Speed': 'mean'
    }).reset_index()
    
    area_tab1, area_tab2, area_tab3 = st.tabs(["📊 Traffic Volume by Area", "🛑 Congestion Level by Area", "⚡ Speed by Area"])
    with area_tab1:
        fig_a1 = px.bar(area_df.sort_values('Traffic Volume', ascending=False), x='Area Name', y='Traffic Volume', color='Traffic Volume', color_continuous_scale='Blues', title='Average Traffic Volume by District')
        st.plotly_chart(fig_a1, use_container_width=True)
    with area_tab2:
        fig_a2 = px.bar(area_df.sort_values('Congestion Level', ascending=False), x='Area Name', y='Congestion Level', color='Congestion Level', color_continuous_scale='Reds', title='Average Congestion Percentage by District')
        st.plotly_chart(fig_a2, use_container_width=True)
    with area_tab3:
        fig_a3 = px.bar(area_df.sort_values('Average Speed', ascending=False), x='Area Name', y='Average Speed', color='Average Speed', color_continuous_scale='YlGnBu', title='Average Velocities by District')
        st.plotly_chart(fig_a3, use_container_width=True)
        
    st.markdown("---")
    
    # Road Analysis
    st.markdown("#### 🛣️ Top Bottleneck and Corridor Rank")
    road_df = df.groupby('Road/Intersection Name').agg({
        'Traffic Volume': 'mean',
        'Congestion Level': 'mean'
    }).reset_index()
    
    road_col1, road_col2 = st.columns(2)
    with road_col1:
        top_traf_roads = road_df.sort_values('Traffic Volume', ascending=False).head(8)
        fig_r1 = px.bar(top_traf_roads, y='Road/Intersection Name', x='Traffic Volume', orientation='h', title='Top 8 Highest Volume Intersections', color='Traffic Volume', color_continuous_scale='Purples')
        fig_r1.update_layout(yaxis={'categoryorder':'total ascending'})
        st.plotly_chart(fig_r1, use_container_width=True)
    with road_col2:
        top_cong_roads = road_df.sort_values('Congestion Level', ascending=False).head(8)
        fig_r2 = px.bar(top_cong_roads, y='Road/Intersection Name', x='Congestion Level', orientation='h', title='Top 8 Most Congested Intersections', color='Congestion Level', color_continuous_scale='Oranges')
        fig_r2.update_layout(yaxis={'categoryorder':'total ascending'})
        st.plotly_chart(fig_r2, use_container_width=True)
        
    st.markdown("---")
    
    # Interactive Drill-down Module
    st.markdown("#### 🔍 Interactive Micro-Corridor Drill-Down")
    drill_c1, drill_c2 = st.columns(2)
    with drill_c1:
        selected_area = st.selectbox("1. Filter by Administrative Area:", sorted(df['Area Name'].unique()))
    with drill_c2:
        filtered_roads = sorted(df[df['Area Name'] == selected_area]['Road/Intersection Name'].unique())
        selected_road = st.selectbox("2. Select Specific Road Node:", filtered_roads)
        
    drill_target = df[(df['Area Name'] == selected_area) & (df['Road/Intersection Name'] == selected_road)]
    
    if not drill_target.empty:
        sc1, sc2, sc3, sc4 = st.columns(4)
        sc1.metric("Selected Segment Traffic", f"{int(drill_target['Traffic Volume'].mean()):,}")
        sc2.metric("Selected Segment Speed", f"{drill_target['Average Speed'].mean():.1f} km/h")
        sc3.metric("Selected Segment Congestion", f"{drill_target['Congestion Level'].mean():.1f}%")
        sc4.metric("Aggregated Incident Reports", f"{int(drill_target['Incident Reports'].sum())}")
        
    st.markdown("---")
    
    # Dynamic Summary Table
    st.markdown("#### 📄 Location Performance Summary Mini-Report Table")
    report_table = df[['Area Name', 'Road/Intersection Name', 'Traffic Volume', 'Congestion Level', 'Average Speed', 'Travel Time Index']].copy()
    report_table['Traffic Volume'] = report_table['Traffic Volume'].astype(int)
    report_table['Congestion Level'] = report_table['Congestion Level'].round(2)
    report_table['Average Speed'] = report_table['Average Speed'].round(2)
    
    st.dataframe(report_table, use_container_width=True, hide_index=True)

# ---------------------------------------------------------
# Page 3 — Factors Affecting Traffic
# ---------------------------------------------------------
elif page == "Page 3 — Factors Affecting Traffic":
    st.title("⚡ Page 3 — Factors Affecting Traffic")
    st.markdown("### **Business Question:** Why does congestion occur?")
    st.markdown("_Isolating causality vectors by inspecting structural variables like weather degradation, construction disruption, and multi-variable interaction matrixes._")
    st.markdown("---")
    
    # Interactive Selector Matrix for Weather/Construction
    st.markdown("#### ☁️ & 🚧 External Impediment Metric Selection Explorer")
    metric_selection = st.selectbox(
        "Select Performance Metric to Analyze Across External Influences:",
        ['Traffic Volume', 'Congestion Level', 'Average Speed']
    )
    
    fact_col1, fact_col2 = st.columns(2)
    with fact_col1:
        w_data = df.groupby('Weather Conditions')[metric_selection].mean().reset_index()
        fig_w = px.bar(w_data.sort_values(metric_selection, ascending=False), x='Weather Conditions', y=metric_selection, title=f'Weather Impact on Average {metric_selection}', color=metric_selection, color_continuous_scale='Viridis')
        st.plotly_chart(fig_w, use_container_width=True)
    with fact_col2:
        c_data = df.groupby('Roadwork and Construction Activity')[metric_selection].mean().reset_index()
        fig_c = px.bar(c_data, x='Roadwork and Construction Activity', y=metric_selection, title=f'Construction Impact on Average {metric_selection}', color=metric_selection, color_continuous_scale='rdbu')
        st.plotly_chart(fig_c, use_container_width=True)
        
    st.markdown("---")
    
    # Flexible Relationship Scatter Plot Analysis
    st.markdown("#### 🔬 Bivariate Variable Relationship Explorer")
    numeric_choices = ['Traffic Volume', 'Average Speed', 'Congestion Level', 'Travel Time Index', 'Environmental Impact', 'Public Transport Usage']
    
    scat_c1, scat_c2, scat_c3 = st.columns(3)
    with scat_c1:
        x_var = st.selectbox("Select Independent Variable (X-Axis):", numeric_choices, index=0)
    with scat_c2:
        y_var = st.selectbox("Select Dependent Variable (Y-Axis):", numeric_choices, index=2)
    with scat_c3:
        color_by = st.selectbox("Categorical Color Stratification:", ['Weather Conditions', 'Roadwork and Construction Activity', 'Weekend_Status'])
        
    # Sample down plot dataset if too dense for local render optimization
    sample_size = min(2500, len(df))
    df_sample = df.sample(n=sample_size, random_state=42)
    
    fig_scatter = px.scatter(
        df_sample, x=x_var, y=y_var, color=color_by,
        title=f"Bivariate Analysis: {x_var} vs {y_var} (Sample Size: {sample_size})",
        opacity=0.65, trendline="ols" if x_var != y_var else None
    )
    st.plotly_chart(fig_scatter, use_container_width=True)
    
    st.markdown("---")
    
    # Full Numerical Correlation Heatmap Matrix
    st.markdown("#### 🧮 Comprehensive Variable Cross-Correlation Heatmap")
    all_numeric_cols = [
        'Traffic Volume', 'Average Speed', 'Travel Time Index', 'Congestion Level', 
        'Road Capacity Utilization', 'Incident Reports', 'Environmental Impact', 
        'Public Transport Usage', 'Traffic Signal Compliance', 'Parking Usage', 'Pedestrian and Cyclist Count'
    ]
    corr_matrix = df[all_numeric_cols].corr()
    
    fig_heat = px.imshow(
        corr_matrix, text_auto=".2f", aspect="auto",
        labels=dict(color="Pearson Corr"),
        title="Linear Correlation Coefficients Grid",
        color_continuous_scale='RdBu_r', zmin=-1, zmax=1
    )
    st.plotly_chart(fig_heat, use_container_width=True)

# ---------------------------------------------------------
# Page 4 — Business Insights
# ---------------------------------------------------------
elif page == "Page 4 — Business Insights":
    st.title("💡 Page 4 — Business Insights & Policy Decisions")
    st.markdown("### **Business Question:** What actions should the traffic department take?")
    st.markdown("_Translation of dataset statistics into strategic governance directives, target action groups, and compliance frameworks._")
    st.markdown("---")
    
    # Calculate Dynamic Metric Insight Targets
    h_traffic_area = df_raw.groupby('Area Name')['Traffic Volume'].mean().idxmax()
    h_cong_area = df_raw.groupby('Area Name')['Congestion Level'].mean().idxmax()
    h_cong_road = df_raw.groupby('Road/Intersection Name')['Congestion Level'].mean().idxmax()
    h_speed_road = df_raw.groupby('Road/Intersection Name')['Average Speed'].mean().idxmax()
    l_cong_road = df_raw.groupby('Road/Intersection Name')['Congestion Level'].mean().idxmin()
    
    # Dynamic Insight Cards Row
    st.markdown("#### 🚨 Automated Operational Priority Insights")
    card_col1, card_col2, card_col3 = st.columns(3)
    card_col1.metric("🔥 Peak Traffic Load Hub", h_traffic_area, "Highest Mean Influx Volume")
    card_col2.metric("🛑 Systemic Gridlock District", h_cong_area, "Highest Core Congestion")
    card_col3.metric("⚠️ Worst Infrastructure Bottleneck", h_cong_road, "Max Commuter Delay Point")
    
    card_col4, card_col5 = st.columns(2)
    card_col4.metric("⚡ Most Fluid Velocity Corridor", h_speed_road, "Highest Safe Operating Speed")
    card_col5.metric("🟢 Lowest Residual Congestion Segment", l_cong_road, "Optimal Flow Status")
    
    st.markdown("---")
    
    # Data Ranking Matrices
    st.markdown("#### 🏆 Top-5 Infrastructure Priorities Rankings")
    rank_c1, rank_c2, rank_c3 = st.columns(3)
    
    with rank_c1:
        st.markdown("##### 🚨 Top 5 Most Congested Roads")
        r1_data = df_raw.groupby('Road/Intersection Name')['Congestion Level'].mean().reset_index().sort_values('Congestion Level', ascending=False).head(5)
        for idx, (_, row) in enumerate(r1_data.iterrows(), 1):
            st.write(f"**{idx}.** {row['Road/Intersection Name']} ({row['Congestion Level']:.1f}%)")
            
    with rank_c2:
        st.markdown("##### 🚗 Top 5 Highest Load Areas")
        r2_data = df_raw.groupby('Area Name')['Traffic Volume'].mean().reset_index().sort_values('Traffic Volume', ascending=False).head(5)
        for idx, (_, row) in enumerate(r2_data.iterrows(), 1):
            st.write(f"**{idx}.** {row['Area Name']} ({int(row['Traffic Volume']):,} units)")
            
    with rank_c3:
        st.markdown("##### ⚡ Top 5 Fastest Running Corridors")
        r3_data = df_raw.groupby('Road/Intersection Name')['Average Speed'].mean().reset_index().sort_values('Average Speed', ascending=False).head(5)
        for idx, (_, row) in enumerate(r3_data.iterrows(), 1):
            st.write(f"**{idx}.** {row['Road/Intersection Name']} ({row['Average Speed']:.1f} km/h)")
    
    # Systemic Context-Aware Recommendations Block
    st.markdown("#### 📋 Targeted Policy & Action Plan Recommendations")
    st.warning("⚠️ **Data-Driven Governance Guidelines for Immediate Implementation:**")
    
    st.markdown(f"""
    1. **Dynamic Enforcement Deployments:** Direct high-visibility traffic warden arrays to **{h_cong_road}** inside **{h_cong_area}** during standard bottleneck cycles to eliminate delays caused by manual parking infractions.
    2. **Adaptive Signal Timing Architecture:** Convert fixed cyclic traffic signal systems at intersections along **{h_cong_road}** to AI adaptive tracking sensors that scale green times dynamically based on incoming lane volumes.
    3. **Enforced Public Transit Prioritization Lanes:** Build separate high-capacity bus prioritization thoroughfares between residential zones and **{h_traffic_area}** to reduce single-occupancy vehicle counts during rush hours.
    4. **Regulated Infrastructure & Roadwork Scheduling:** Mandate that **Roadwork and Construction Activity** move exclusively to low-impact overnight shifts (10:00 PM - 5:00 AM) with strict delay fine clauses.
    5. **Micro-Chokepoint Road Widening Schemes:** Initiate targeted widening assessments for localized turn lanes and bottleneck nodes on identified high-capacity stress segments.
    """)
    
    st.markdown("---")
    
    # Data Report and Filtration Export Center
    st.markdown("#### 💾 Municipal Reporting & Data Export Center")
    
    csv_bytes = df.to_csv(index=False).encode('utf-8')
    
    business_text_report = f"""=========================================================
BANGALORE MUNICIPAL TRANSIT PERFORMANCE SUMMARY REPORT
=========================================================
Data Baseline Record Length: {len(df_raw)} intervals analyzed.

CORE GEOGRAPHIC INSIGHTS:
- Highest Load Operational District: {h_traffic_area}
- Worst Core Gridlock Hotspot Area: {h_cong_area}
- Maximum Micro Corridor Delay Segment: {h_cong_road}
- Best Performing Flow Corridor: {h_speed_road}

URGENT POLICY MANDATES:
1. Shift construction activities to strict night windows.
2. Upgrade smart signaling frameworks on {h_cong_road}.
3. Deploy rapid-clearing crews to primary congestion loops.
"""
    
    dl1, dl2 = st.columns(2)
    with dl1:
        st.download_button(
            label="📥 Download Filtered Dataset Target (CSV)",
            data=csv_bytes,
            file_name="Bangalore_Traffic_Filtered_Data.csv",
            mime="text/csv",
            use_container_width=True
        )
    with dl2:
        st.download_button(
            label="📄 Export Business Executive Policy Report (TXT)",
            data=business_text_report,
            file_name="Transit_Executive_Policy_Report.txt",
            mime="text/plain",
            use_container_width=True
        )
